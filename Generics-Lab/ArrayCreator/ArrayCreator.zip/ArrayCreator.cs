﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericArrayCreator
{
    class ArrayCreator<T>
    {
       public static T[] Create(int lenght, T value)
        {
            T[] elements = new T[lenght];
            int counter = 0;
            foreach (var item in elements)
            {
                elements[counter] = value;
                counter++;
            }
            return elements;
        }
    }
}
