﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06._Speed_Racing
{
    class Car
    {
    }
}
