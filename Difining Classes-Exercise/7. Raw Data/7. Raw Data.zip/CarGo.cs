﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _7._Raw_Data
{
    class CarGo
    {
        private string type;
        private int weight;

        public CarGo(string type, int weight)
        {
            Type = type;
            Weight = weight;
        }

        public string Type { get; set; }
        public int Weight { get; set; }
    }
}
